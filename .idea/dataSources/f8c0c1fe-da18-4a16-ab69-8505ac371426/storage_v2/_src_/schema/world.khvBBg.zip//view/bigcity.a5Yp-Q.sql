create view bigcity as
select `c`.`ID`          AS `ID`,
       `c`.`Name`        AS `Name`,
       `c`.`CountryCode` AS `CountryCode`,
       `c`.`District`    AS `District`,
       `c`.`Population`  AS `Population`
from `world`.`city` `c`
where (`c`.`Population` > 1000000);

