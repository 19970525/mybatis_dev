create
    definer = root@`%` procedure addCity_procedure(IN numb int)
BEGIN
	DECLARE i INT DEFAULT 0;
	SET autocommit=0;
	START TRANSACTION;
	WHILE i<=numb  DO
		SET i=i+1;
		INSERT INTO city(`Name`,CountryCode,District,Population)
		VALUES(CONCAT('苏州',i),'ZWE','111',i);
	END WHILE;
	COMMIT;
	SELECT CONCAT('添加完成数：',i);
END;

