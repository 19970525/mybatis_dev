create definer = root@`%` view turbigcity as
select `bigcity`.`ID`          AS `ID`,
       `bigcity`.`Name`        AS `Name`,
       `bigcity`.`CountryCode` AS `CountryCode`,
       `bigcity`.`District`    AS `District`,
       `bigcity`.`Population`  AS `Population`
from `world`.`bigcity`
where (`bigcity`.`CountryCode` = 'TUR');

