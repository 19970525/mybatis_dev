create view aaasa as
select `girls`.`beauty`.`id`           AS `id`,
       `girls`.`beauty`.`name`         AS `name`,
       `girls`.`beauty`.`sex`          AS `sex`,
       `girls`.`beauty`.`borndate`     AS `borndate`,
       `girls`.`beauty`.`phone`        AS `phone`,
       `girls`.`beauty`.`photo`        AS `photo`,
       `girls`.`beauty`.`boyfriend_id` AS `boyfriend_id`
from `girls`.`beauty`;

